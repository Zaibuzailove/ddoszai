import requests
import os
import subprocess
import random
import re
import threading
import urllib.request
import argparse
import sys
from colorama import Fore, Back, Style, init
from time import time

init(autoreset=True)

output_file = 'proxy.txt'
os.system('cls' if os.name == 'nt' else 'clear')

if os.path.isfile(output_file):
    os.remove(output_file)
    print(f"{Fore.RED}'proxy.txt' telah dihapus.{Fore.RESET}")

print(f"{Fore.YELLOW}Otw Download\n")

proxy_urls = [
'https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/socks4.txt',
'http://atomintersoft.com/anonymous_proxy_list',
'https://www.proxy-list.download/SOCKS5',
'https://api.proxyscrape.com/v2/?request=getproxies&protocol=http&timeout=10000&country=all&ssl=all&anonymity=anonymous',
'https://github.com/jetkai/proxy-list/blob/main/online-proxies/txt/proxies-socks4.txt',
'https://www.proxy-list.download/api/v1/get?type=https',
'https://raw.githubusercontent.com/casals-ar/proxy-list/main/https',
'https://www.proxy-list.download/api/v1/get?type=socks4',
'https://api.proxyscrape.com/v2/?request=displayproxies&protocol=socks5&timeout=10000&country=all',
'https://raw.githubusercontent.com/mertguvencli/http-proxy-list/main/proxy-list/data.txt',
'https://github.com/jetkai/proxy-list/blob/main/online-proxies/txt/proxies-http.txt',
'https://spys.me/socks.txt',
'http://proxyfirenet.blogspot.com/',
'https://www.freeproxy.world/?type=&anonymity=&country=&speed=&port=&page=[page]',
'http://proxydb.net/?protocol=https',
'https://github.com/jetkai/proxy-list/blob/main/online-proxies/txt/proxies-https.txt',
'http://vipprox.blogspot.com/2013/05/us-proxy-servers-74_24.html',
'http://vipprox.blogspot.com/2013_06_01_archive.html',
'http://vipprox.blogspot.com/2013/05/us-proxy-servers-199_20.html',
'http://atomintersoft.com/products/alive-proxy/proxy-list/3128',
'https://raw.githubusercontent.com/zloi-user/hideip.me/main/https.txt',
'http://browse.feedreader.com/c/Proxy_Server_List-1/449196259',
'https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/http.txt',
'http://worm.rip/https.txt',
'https://premiumproxy.net/full-proxy-list',
'https://raw.githubusercontent.com/RX4096/proxy-list/main/online/socks4.txt',
'https://raw.githubusercontent.com/rdavydov/proxy-list/main/proxies/socks4.txt',
'https://api.proxyscrape.com/?request=displayproxies&proxytype=socks4',
'https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/http.txt',
'http://vipprox.blogspot.com/2013_02_01_archive.html',
'https://raw.githubusercontent.com/casals-ar/proxy-list/main/socks4',
'https://raw.githubusercontent.com/ErcinDedeoglu/proxies/main/proxies/http.txt',
'https://list.proxylistplus.com/Fresh-HTTP-Proxy-List-[page]',
'https://raw.githubusercontent.com/clarketm/proxy-list/master/proxy-list-raw.txt',
'https://raw.githubusercontent.com/almroot/proxylist/master/list.txt',
'https://raw.githubusercontent.com/RX4096/proxy-list/main/online/http.txt',
'https://raw.githubusercontent.com/hookzof/socks5_list/master/proxy.txt',
'https://free-proxy-list.net/',
'https://raw.githubusercontent.com/monosans/proxy-list/main/proxies_anonymous/all.txt',
'https://api.proxyscrape.com/v2/?request=getproxies&protocol=http&timeout=10000&country=all&ssl=all&anonymity=all',
'https://www.us-proxy.org/',
'https://premproxy.com/list/',
'https://apiproxyfree.com/',
'http://olaf4snow.com/public/proxy.txt',
'https://multiproxy.org/txt_all/proxy.txt',
'https://api.proxyscrape.com/?request=displayproxies&proxytype=all',
'https://raw.githubusercontent.com/proxy4parsing/proxy-list/main/http.txt',
'http://rootjazz.com/proxies/proxies.txt',
'https://raw.githubusercontent.com/VampXDH/Proxy/main/proxy.txt',
'https://proxyspace.pro/socks5.txt',
'http://atomintersoft.com/proxy_list_port_8000',
'https://github.com/themiralay/Proxy-List-World/raw/master/data.txt',
'https://github.com/im-razvan/proxy_list/raw/main/http.txt',
'https://api.openproxylist.xyz/http.txt',
'https://raw.githubusercontent.com/saisuiu/Lionkings-Http-Proxys-Proxies/main/cnfree.txt',
'http://proxydb.net/?protocol=socks4',
'http://atomintersoft.com/transparent_proxy_list',
'https://raw.githubusercontent.com/proxylist-to/proxy-list/main/socks4.txt',
'https://raw.githubusercontent.com/officialputuid/KangProxy/KangProxy/socks4/socks4.txt',
'https://advanced.name/freeproxy?page=[page]',
'http://freeproxylist-daily.blogspot.com/2013/05/usa-proxy-list-2013-05-13-812-gmt7.html',
'https://proxyspace.pro/http.txt',
'https://raw.githubusercontent.com/zevtyardt/proxy-list/main/http.txt',
'https://raw.githubusercontent.com/officialputuid/KangProxy/KangProxy/xResults/RAW.txt',
'http://tomoney.narod.ru/help/proxi.htm',
'http://worm.rip/http.txt',
'https://raw.githubusercontent.com/officialputuid/KangProxy/KangProxy/xResults/old-data/Proxies.txt',
'https://raw.githubusercontent.com/UptimerBot/proxy-list/main/proxies/socks5.txt',
'http://atomintersoft.com/proxy_list_domain_org',
'https://raw.githubusercontent.com/sunny9577/proxy-scraper/master/proxies.txt',
'https://raw.githubusercontent.com/officialputuid/KangProxy/KangProxy/https/https.txt',
'https://slims-sf.com/Htewarukofdcn/https.txt',
'http://browse.feedreader.com/c/Proxy_Server_List-1/449196258',
'http://browse.feedreader.com/c/Proxy_Server_List-1/449196260',
'https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/proxy.txt',
'https://api.proxyscrape.com/v2/?request=displayproxies&protocol=http&timeout=10000&country=all&ssl=all&anonymity=all',
'https://raw.githubusercontent.com/jetkai/proxy-list/main/online-proxies/txt/proxies-socks5.txt',
'https://api.proxyscrape.com/v2/?request=displayproxies&protocol=socks5',
'https://www.netzwelt.de/proxy/index.html',
'https://raw.githubusercontent.com/roosterkid/openproxylist/main/SOCKS4_RAW.txt',
'https://slims-sf.com/Htewarukofdcn/proxy.txt',
'https://raw.githubusercontent.com/ALIILAPRO/Proxy/main/socks5.txt',
'https://raw.githubusercontent.com/Tsprnay/Proxy-lists/master/proxies/all.txt',
'https://api.openproxylist.xyz/socks5.txt',
'https://raw.githubusercontent.com/vakhov/fresh-proxy-list/master/https.txt',
'https://raw.githubusercontent.com/UptimerBot/proxy-list/main/proxies/http.txt',
'http://proxydb.net/?protocol=http',
'https://raw.githubusercontent.com/caliphdev/Proxy-List/master/http.txt',
'https://raw.githubusercontent.com/proxifly/free-proxy-list/main/proxies/protocols/http/data.txt',
'https://api.proxyscrape.com/v2/?request=getproxies&protocol=socks5&timeout=10000&country=all&simplified=true',
'https://openproxy.space/list/socks5',
'https://raw.githubusercontent.com/elliottophellia/yakumo/master/results/socks5/global/socks5_checked.txt',
'https://raw.githubusercontent.com/Firdoxx/proxy-list/main/https',
'http://atomintersoft.com/proxy_list_port_81',
'http://atomintersoft.com/proxy_list_domain_edu',
'http://browse.feedreader.com/c/Proxy_Server_List-1/449196251',
'https://raw.githubusercontent.com/saisuiu/Lionkings-Http-Proxys-Proxies/main/free.txt',
'http://johnstudio0.tripod.com/index1.htm',
'https://raw.githubusercontent.com/proxifly/free-proxy-list/main/proxies/protocols/socks5/data.txt',
'https://raw.githubusercontent.com/prxchk/proxy-list/main/socks5.txt',
'https://cyber-hub.pw/statics/proxy.txt',
'https://raw.githubusercontent.com/stokdigitalocean12345/Cheerio/main/puki.txt',
'https://raw.githubusercontent.com/RX4096/proxy-list/main/online/https.txt',
'https://www.javatpoint.com/proxy-server-list',
'https://raw.githubusercontent.com/prxchk/proxy-list/main/http.txt',
'https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/socks4.txt',
'https://sunny9577.github.io/proxy-scraper/generated/http_proxies.txt',
'https://raw.githubusercontent.com/Jakee8718/Free-Proxies/main/proxy/-http%20and%20https.txt',
'https://free-proxy-list.net',
'https://raw.githubusercontent.com/rdavydov/proxy-list/main/proxies/http.txt',
'https://www.proxy-list.download/SOCKS4',
'https://raw.githubusercontent.com/zloi-user/hideip.me/main/http.txt',
'https://raw.githubusercontent.com/zloi-user/hideip.me/main/socks5.txt',
'https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt',
'https://www.freeproxy.world/',
'http://atomintersoft.com/products/alive-proxy/proxy-list/high-anonymity/',
'https://openproxy.space/list/socks4',
'https://api.proxyscrape.com/v2/?request=displayproxies&protocol=socks5&timeout=10000&country=all&ssl=all&anonymity=all',
'http://www.cybersyndrome.net/pla6.html',
'https://raw.githubusercontent.com/Anonym0usWork1221/Free-Proxies/main/proxy_files/socks5_proxies.txt',
'https://raw.githubusercontent.com/B4RC0DE-TM/proxy-list/main/HTTP.txt',
'http://sergei-m.narod.ru/proxy.htm',
'https://raw.githubusercontent.com/opsxcq/proxy-list/master/list.txt',
'http://greenrain.bos.ru/R_Stuff/Proxy.htm',
'http://www.cybersyndrome.net/pla5.html',
'https://raw.githubusercontent.com/TheSpeedX/SOCKS-List/master/socks4.txt',
'https://raw.githubusercontent.com/roosterkid/openproxylist/main/SOCKS5_RAW.txt',
'http://hack-hack.chat.ru/proxy/p1.txt',
'https://github.com/jetkai/proxy-list/blob/main/online-proxies/txt/proxies.txt',
'https://api.proxyscrape.com/?request=getproxies&proxytype=https&timeout=10000&country=all&ssl=all&anonymity=all',
'https://raw.githubusercontent.com/Tsprnay/Proxy-lists/master/proxies/http.txt',
'https://www.proxy-list.download/api/v1/get?type=socks5',
'https://raw.githubusercontent.com/jetkai/proxy-list/main/online-proxies/txt/proxies.txt',
'https://raw.githubusercontent.com/monosans/proxy-list/main/proxies_anonymous/socks4.txt',
'https://github.com/MrMarble/proxy-list/raw/main/all.txt',
'http://alexa.lr2b.com/proxylist.txt',
'https://raw.githubusercontent.com/Firdoxx/proxy-list/main/http',
'https://api.proxyscrape.com/v2/?request=getproxies&protocol=socks4&timeout=10000&country=all&ssl=all&anonymity=all',
'https://raw.githubusercontent.com/vakhov/fresh-proxy-list/master/http.txt',
'https://raw.githubusercontent.com/mmpx12/proxy-list/master/socks4.txt',
'https://raw.githubusercontent.com/UptimerBot/proxy-list/main/proxies/socks4.txt',
'https://raw.githubusercontent.com/RX4096/proxy-list/main/online/socks5.txt',
'https://proxyservers.pro/',
'https://github.com/andigwandi/free-proxy/raw/main/proxy_list.txt',
'http://vipprox.blogspot.com/2013_03_01_archive.html',
'https://raw.githubusercontent.com/proxylist-to/proxy-list/main/http.txt',
'https://api.proxyscrape.com/v2/?request=displayproxies&protocol=socks4&timeout=10000&country=all',
'http://sockproxy.blogspot.com/2013/04/11-04-13-socks-45.html',
'http://hack-hack.chat.ru/proxy/p4.txt',
'https://raw.githubusercontent.com/officialputuid/KangProxy/KangProxy/socks5/socks5.txt',
'http://atomintersoft.com/proxy_list_port_80',
'https://raw.githubusercontent.com/im-razvan/proxy_list/main/http.txt',
'https://raw.githubusercontent.com/a2u/free-proxy-list/master/free-proxy-list.txt',
'https://raw.githubusercontent.com/mishakorzik/Free-Proxy/main/proxy.txt',
'https://shieldcommunity.net/sockets.txt',
'http://freeproxylist-daily.blogspot.com/2013/05/usa-proxy-list-2013-05-15-0111-am-gmt8.html',
'https://raw.githubusercontent.com/prxchk/proxy-list/main/all.txt',
'https://github.com/im-razvan/proxy_list/raw/main/socks5',
'http://rammstein.narod.ru/proxy.html',
'https://www.proxynova.com/proxy-server-list/',
'https://www.proxy-list.download/HTTPS',
'https://raw.githubusercontent.com/Tsprnay/Proxy-lists/master/proxies/https.txt',
'https://raw.githubusercontent.com/sunny9577/proxy-scraper/master/generated/socks5_proxies.txt',
'https://raw.githubusercontent.com/manuGMG/proxy-365/main/SOCKS5.txt',
'http://hack-hack.chat.ru/proxy/p2.txt',
'https://raw.githubusercontent.com/jetkai/proxy-list/main/online-proxies/txt/proxies-socks4.txt',
'https://raw.githubusercontent.com/proxylist-to/proxy-list/main/socks5.txt',
'http://free-proxy.cz/en/web-proxylist/',
'https://proxyspace.pro/socks4.txt',
'https://raw.githubusercontent.com/im-razvan/proxy_list/main/socks5.txt',
'https://www.proxy-list.download/HTTP',
'http://atomintersoft.com/proxy_list_domain_com',
'https://raw.githubusercontent.com/TheSpeedX/SOCKS-List/master/socks5.txt',
'https://www.proxydocker.com/',
'https://github.com/ALIILAPRO/Proxy/raw/main/http.txt',
'https://raw.githubusercontent.com/Anonym0usWork1221/Free-Proxies/main/proxy_files/http_proxies.txt'
'https://raw.githubusercontent.com/MuRongPIG/Proxy-Master/main/socks5.txt',
'https://github.com/TuanMinPay/live-proxy/raw/master/all.txt',
'https://openproxy.space/list/http',
'http://atomintersoft.com/high_anonymity_elite_proxy_list',
'https://raw.githubusercontent.com/MuRongPIG/Proxy-Master/main/http.txt',
'https://raw.githubusercontent.com/Zaeem20/FREE_PROXIES_LIST/master/https.txt',
'https://raw.githubusercontent.com/yuceltoluyag/GoodProxy/main/GoodProxy.txt',
'http://atomintersoft.com/products/alive-proxy/proxy-list/com',
'https://raw.githubusercontent.com/ALIILAPRO/Proxy/main/http.txt',
'http://proxydb.net/?protocol=socks5',
'https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/socks4.txt',
'http://atomintersoft.com/products/alive-proxy/socks5-list',
'https://raw.githubusercontent.com/aslisk/proxyhttps/main/https.txt',
'http://hack-hack.chat.ru/proxy/allproxy.txt',
'http://free-ssh.blogspot.com/feeds/posts/default',
'https://raw.githubusercontent.com/sunny9577/proxy-scraper/master/generated/socks4_proxies.txt',
'https://raw.githubusercontent.com/mmpx12/proxy-list/master/socks5.txt',
'https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/socks5.txt',
'https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/socks5.txt',
'http://proxydb.net/',
'https://premiumproxy.net/',
'https://www.proxyscan.io/download?type=socks4',
'https://proxy-spider.com/api/proxies.example.txt',
'https://api.proxyscrape.com/?request=displayproxies&proxytype=socks5',
'https://free-proxy-list.com/?page=[page]&port=&up_time=0',
'http://hack-hack.chat.ru/proxy/anon.tx',
'https://raw.githubusercontent.com/rdavydov/proxy-list/main/proxies/socks5.txt',
'https://raw.githubusercontent.com/hendrikbgr/Free-Proxy-Repo/master/proxy_list.txt',
'https://www.proxydocker.com/en/proxylist/download?email=noshare&country=all&city=all&port=all&type=all&anonymity=all&state=all&need=all',
'https://sunny9577.github.io/proxy-scraper/generated/socks5_proxies.txt',
'https://raw.githubusercontent.com/casals-ar/proxy-list/main/http',
'https://proxy-daily.com/',
'http://atomintersoft.com/proxy_list_port_3128',
'https://raw.githubusercontent.com/mallisc5/master/proxy-list-raw.txt',
'https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/socks5.txt',
'https://api.proxyscrape.com/v2/?request=displayproxies',
'http://atomintersoft.com/proxy_list_domain_net',
'http://vipprox.blogspot.com/p/blog-page_7.html',
'https://raw.githubusercontent.com/Zaeem20/FREE_PROXIES_LIST/master/socks5.txt',
'https://proxyspace.pro/https.txt',
'https://github.com/jetkai/proxy-list/blob/main/online-proxies/txt/proxies-socks5.txt',
'https://raw.githubusercontent.com/mmpx12/proxy-list/master/http.txt',
'https://raw.githubusercontent.com/tuanminpay/live-proxy/master/http.txt',
'https://openproxylist.xyz/socks5.txt',
'https://raw.githubusercontent.com/Anonym0usWork1221/Free-Proxies/main/proxy_files/https_proxies.txt',
'https://raw.githubusercontent.com/elliottophellia/yakumo/master/results/http/global/http_checked.txt',
'https://raw.githubusercontent.com/officialputuid/KangProxy/KangProxy/http/http.txt',
'https://openproxylist.xyz/http.txt',
'https://smallseotools.com/de/free-proxy-list/',
'https://hidemy.name/en/proxy-list/?start=[page]',
'https://www.proxyscan.io/download?type=socks5',
'https://raw.githubusercontent.com/jetkai/proxy-list/main/online-proxies/txt/proxies-http.txt',
'http://sock5us.blogspot.com/2013/06/01-07-13-free-proxy-server-list.html',
'https://raw.githubusercontent.com/casals-ar/proxy-list/main/socks5',
'https://raw.githubusercontent.com/Anonym0usWork1221/Free-Proxies/main/proxy_files/socks4_proxies.txt',
'https://www.proxyscan.io/download?type=https',
'https://notabug.org/cyberfront/proxy-list/raw/master/socks5.txt',
'https://api.proxyscrape.com/?request=displayproxies&proxytype=https',
'https://api.proxyscrape.com/?request=displayproxies&proxytype=http',
'https://raw.githubusercontent.com/mmpx12/proxy-list/master/https.txt',
'https://raw.githubusercontent.com/MuRongPIG/Proxy-Master/main/socks4.txt',
'https://raw.githubusercontent.com/yuceltoluyag/GoodProxy/main/raw.txt',
'https://raw.githubusercontent.com/jetkai/proxy-list/main/online-proxies/txt/proxies-https.txt',
'https://api.proxyscrape.com/?request=getproxies&proxytype=http&timeout=10000&country=all&ssl=all&anonymity=all',
'https://raw.githubusercontent.com/HyperBeats/proxy-list/main/https.txt',
'http://westdollar.narod.ru/proxy.htm',
'https://api.proxyscrape.com/v2/?request=getproxies&protocol=socks5&timeout=10000&country=all',
'https://www.proxy-list.download/api/v1/get?type=http',
'https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/https.txt',
'https://www.proxyscan.io/download?type=http',
'https://vpnoverview.com/privacy/anonymous-browsing/free-proxy-servers/',
'https://raw.githubusercontent.com/proxy4parsing/proxy-list/main/http_old.txt',
'https://raw.githubusercontent.com/roosterkid/openproxylist/main/HTTPS_RAW.txt',
'https://slims-sf.com/Htewarukofdcn/http.txt',
'https://api.openproxylist.xyz/socks4.txt',
'https://raw.githubusercontent.com/Zaeem20/FREE_PROXIES_LIST/master/http.txt',
'http://inav.chat.ru/ftp/proxy.txt',
'https://raw.githubusercontent.com/sunny9577/proxy-scraper/master/generated/http_proxies.txt',
'https://raw.githubusercontent.com/TheSpeedX/SOCKS-List/master/http.txt',
'http://hack-hack.chat.ru/proxy/p3.txt',
'https://cdn.jsdelivr.net/gh/monosans/proxy-list@main/proxies/socks4.txt',
'https://pastebin.com/raw/K7x4Sk9r',
'https://pastebin.com/raw/N7TBpGC2',
'https://pastebin.com/raw/gBa4KbvH',
'https://pastebin.com/raw/Kwe1Lrs1',
'https://pastebin.com/raw/6ecVH0fH',
'https://pastebin.com/raw/fksRr3Fh',
'https://pastebin.com/raw/90TkEZ3f',
'https://pastebin.com/raw/X9MrKu9D',
'https://pastebin.com/raw/BAFSmNKe',
'https://pastebin.com/raw/MLhvXhiS',
'https://pastebin.com/raw/F7wBKfxA',
'https://pastebin.com/raw/tSyiqBEV',
'https://pastebin.com/raw/sfmy6sdr',
'http://anonimseti.blogspot.com/feeds/posts/default?alt=rss',
'http://thedarkcrypter.blogspot.com/feeds/posts/default?alt=rss',
'http://red-proxy.blogspot.com/2013/12/scrapebox-anonymous-google-passed_15.html?m=1',
'https://pastebin.com/raw/pvWvSghs',
'https://pastebin.com/raw/yf1epVcc',
'http://proxy-updates.blogspot.com/feeds/posts/default?alt=rss',
'http://feeds.feedburner.com/blogspot/uDqdW',
'https://pastebin.com/raw/sraffBw4',
'https://pastebin.com/raw/Av2rWHgt',
'http://guncelproxys.blogspot.com/feeds/posts/default?alt=rss',
'https://raw.githubusercontent.com/grayskripko/autobots/master/proxyListCache.txt',
'http://pub365.blogspot.com/2013/04/16-04-13-new-daily-hidemyass-premium.html?m=1',
'http://hma-proxy.blogspot.com/feeds/posts/default?alt=rss',
'https://pastebin.com/raw/8HwvVKKk',
'https://pastebin.com/raw/U7v8i42U',
'https://pastebin.com/raw/GJhdB5WL',
'https://pastebin.com/raw/ZcNrYJNC',
'https://pastebin.com/raw/YzMz11pH',
'https://pastebin.com/raw/ysjXrQCs',
'https://pastebin.com/raw/KvMMpr8G',
'http://freessl-proxieslist.blogspot.com/feeds/posts/default?alt=rss'
'https://pastebin.com/raw/qQ8ubjBy',
'https://pastebin.com/raw/HxC5nHSb',
'https://web.archive.org/web/20190922201025/http://search.lores.eu/proxitk1.txt'
'http://othersrvr.com/noa/proxies.txt',
'http://dailyhttpproxies.blogspot.com/feeds/posts/default?alt=rss',
'http://goodproxies.blogspot.com/feeds/posts/default?alt=rss',
'http://freshsocks5.blogspot.com/feeds/posts/default?alt=rss',
'http://proxible.blogspot.com/2013/10/daily-new-proxies-3058.html',
'https://raw.githubusercontent.com/ErcinDedeoglu/proxies/main/proxies/http.txt'
'https://raw.githubusercontent.com/mallisc5/master/proxy-list-raw.txt'
'https://raw.githubusercontent.com/MuRongPIG/Proxy-Master/main/http.txt'
'https://raw.githubusercontent.com/prxchk/proxy-list/main/http.txt'
'https://raw.githubusercontent.com/TheSpeedX/SOCKS-List/master/http.txt'
'https://raw.githubusercontent.com/saisuiu/Lionkings-Http-Proxys-Proxies/main/free.txt'
'https://raw.githubusercontent.com/HyperBeats/proxy-list/main/https.txt'
'https://raw.githubusercontent.com/UptimerBot/proxy-list/main/proxies/http.txt'
'https://raw.githubusercontent.com/caliphdev/Proxy-List/master/http.txt'
'https://raw.githubusercontent.com/proxylist-to/proxy-list/main/http.txt'
'https://raw.githubusercontent.com/zloi-user/hideip.me/main/https.txt'
'https://raw.githubusercontent.com/zloi-user/hideip.me/main/http.txt'
'https://raw.githubusercontent.com/vakhov/fresh-proxy-list/master/https.txt'
'https://raw.githubusercontent.com/vakhov/fresh-proxy-list/master/http.txt'
'https://raw.githubusercontent.com/proxifly/free-proxy-list/main/proxies/protocols/http/data.txt'
'https://raw.githubusercontent.com/tuanminpay/live-proxy/master/http.txt'
'https://raw.githubusercontent.com/casals-ar/proxy-list/main/https'
'https://raw.githubusercontent.com/casals-ar/proxy-list/main/http'
'https://raw.githubusercontent.com/Zaeem20/FREE_PROXIES_LIST/master/http.txt'
'https://raw.githubusercontent.com/Zaeem20/FREE_PROXIES_LIST/master/https.txt'
'https://raw.githubusercontent.com/mmpx12/proxy-list/master/https.txt'
'https://raw.githubusercontent.com/proxy4parsing/proxy-list/main/http.txt'
'https://raw.githubusercontent.com/Anonym0usWork1221/Free-Proxies/main/proxy_files/http_proxies.txt'
'https://raw.githubusercontent.com/Anonym0usWork1221/Free-Proxies/main/proxy_files/https_proxies.txt'
'https://raw.githubusercontent.com/clarketm/proxy-list/master/proxy-list-raw.txt'
'https://raw.githubusercontent.com/sunny9577/proxy-scraper/master/proxies.txt'
'https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/proxy.txt'
'https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/socks4.txt'
'https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/socks5.txt'
'http://atomintersoft.com/proxy_list_port_80'
'http://atomintersoft.com/proxy_list_domain_org'
'http://atomintersoft.com/proxy_list_port_3128'
'https://raw.githubusercontent.com/ErcinDedeoglu/proxies/main/proxies/http.txt'
'https://raw.githubusercontent.com/mallisc5/master/proxy-list-raw.txt'
'https://raw.githubusercontent.com/MuRongPIG/Proxy-Master/main/http.txt'
'https://raw.githubusercontent.com/prxchk/proxy-list/main/http.txt'
'https://raw.githubusercontent.com/TheSpeedX/SOCKS-List/master/http.txt'
'https://raw.githubusercontent.com/saisuiu/Lionkings-Http-Proxys-Proxies/main/free.txt'
'https://raw.githubusercontent.com/HyperBeats/proxy-list/main/https.txt'
'https://raw.githubusercontent.com/UptimerBot/proxy-list/main/proxies/http.txt'
'https://raw.githubusercontent.com/caliphdev/Proxy-List/master/http.txt'
'https://raw.githubusercontent.com/proxylist-to/proxy-list/main/http.txt'
'https://raw.githubusercontent.com/zloi-user/hideip.me/main/https.txt'
'https://raw.githubusercontent.com/zloi-user/hideip.me/main/http.txt'
'https://raw.githubusercontent.com/vakhov/fresh-proxy-list/master/https.txt'
'https://raw.githubusercontent.com/vakhov/fresh-proxy-list/master/http.txt'
'https://raw.githubusercontent.com/proxifly/free-proxy-list/main/proxies/protocols/http/data.txt'
'https://raw.githubusercontent.com/tuanminpay/live-proxy/master/http.txt'
'https://raw.githubusercontent.com/casals-ar/proxy-list/main/https'
'https://raw.githubusercontent.com/casals-ar/proxy-list/main/http'
'https://raw.githubusercontent.com/Zaeem20/FREE_PROXIES_LIST/master/http.txt'
'https://raw.githubusercontent.com/Zaeem20/FREE_PROXIES_LIST/master/https.txt'
'https://raw.githubusercontent.com/mmpx12/proxy-list/master/https.txt'
'https://raw.githubusercontent.com/proxy4parsing/proxy-list/main/http.txt'
'https://raw.githubusercontent.com/Anonym0usWork1221/Free-Proxies/main/proxy_files/http_proxies.txt'
'https://raw.githubusercontent.com/Anonym0usWork1221/Free-Proxies/main/proxy_files/https_proxies.txt'
'https://raw.githubusercontent.com/clarketm/proxy-list/master/proxy-list-raw.txt'
'https://raw.githubusercontent.com/sunny9577/proxy-scraper/master/proxies.txt'
'https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/proxy.txt'
'http://freeproxylist-daily.blogspot.com/2013/05/usa-proxy-list-2013-05-15-0111-am-gmt8.html'
'http://freeproxylist-daily.blogspot.com/2013/05/usa-proxy-list-2013-05-13-812-gmt7.html'
'http://www.cybersyndrome.net/pla5.html'
'http://vipprox.blogspot.com/2013_06_01_archive.html'
'http://vipprox.blogspot.com/2013/05/us-proxy-servers-74_24.html'
'http://vipprox.blogspot.com/p/blog-page_7.html'
'http://vipprox.blogspot.com/2013/05/us-proxy-servers-199_20.html'
'http://vipprox.blogspot.com/2013_02_01_archive.html'
'http://alexa.lr2b.com/proxylist.txt'
'http://vipprox.blogspot.com/2013_03_01_archive.html'
'http://browse.feedreader.com/c/Proxy_Server_List-1/449196260'
'http://browse.feedreader.com/c/Proxy_Server_List-1/449196258'
'http://sock5us.blogspot.com/2013/06/01-07-13-free-proxy-server-list.html'
'http://browse.feedreader.com/c/Proxy_Server_List-1/449196251'
'http://free-ssh.blogspot.com/feeds/posts/default'
'http://browse.feedreader.com/c/Proxy_Server_List-1/449196259'
'http://sockproxy.blogspot.com/2013/04/11-04-13-socks-45.html'
'http://proxyfirenet.blogspot.com/'
'https://www.javatpoint.com/proxy-server-list'
'https://openproxy.space/list/http'
'http://proxydb.net/'
'http://olaf4snow.com/public/proxy.txt'
'http://westdollar.narod.ru/proxy.htm'
'https://openproxy.space/list/socks4'
'https://openproxy.space/list/socks5'
'http://tomoney.narod.ru/help/proxi.htm'
'http://sergei-m.narod.ru/proxy.htm'
'http://rammstein.narod.ru/proxy.html'
'http://greenrain.bos.ru/R_Stuff/Proxy.htm'
'http://inav.chat.ru/ftp/proxy.txt'
'http://johnstudio0.tripod.com/index1.htm'
'http://atomintersoft.com/transparent_proxy_list'
'http://atomintersoft.com/anonymous_proxy_list'
'http://atomintersoft.com/high_anonymity_elite_proxy_list'
'https://raw.githubusercontent.com/roosterkid/openproxylist/main/HTTPS_RAW.txt',
'https://raw.githubusercontent.com/yuceltoluyag/GoodProxy/main/raw.txt',
'https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/http.txt',
'https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/https.txt',
'https://raw.githubusercontent.com/mmpx12/proxy-list/master/https.txt',
'https://proxyspace.pro/http.txt',
'https://api.proxyscrape.com/?request=displayproxies&proxytype=http',
'https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/http.txt',
'http://worm.rip/http.txt',
'http://worm.rip/https.txt',
'http://alexa.lr2b.com/proxylist.txt',
'https://api.openproxylist.xyz/http.txt',
'http://rootjazz.com/proxies/proxies.txt',
'https://multiproxy.org/txt_all/proxy.txt',
'https://proxy-spider.com/api/proxies.example.txt',
'https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt',
'https://raw.githubusercontent.com/jetkai/proxy-list/main/online-proxies/txt/proxies.txt',
'https://raw.githubusercontent.com/hookzof/socks5_list/master/proxy.txt',
'https://raw.githubusercontent.com/clarketm/proxy-list/master/proxy-list-raw.txt',
'https://raw.githubusercontent.com/sunny9577/proxy-scraper/master/proxies.txt',
'https://raw.githubusercontent.com/opsxcq/proxy-list/master/list.txt',
'https://api.proxyscrape.com/v2/?request=getproxies&protocol=http&timeout=10000&country=all&ssl=all&anonymity=all',
'https://www.proxydocker.com/en/proxylist/download?email=noshare&country=all&city=all&port=all&type=all&anonymity=all&state=all&need=all',
'https://api.proxyscrape.com/v2/?request=getproxies&protocol=http&timeout=10000&country=all&ssl=all&anonymity=anonymous',
]

def download_and_save_proxies(url, output_file):
    try:
        response = requests.get(url)
        if response.status_code == 200:
            with open(output_file, 'a') as file:
                file.write(response.text)
                print(f"{Fore.GREEN}Collect: {Fore.WHITE}{url} {Fore.GREEN}")
        else:
            print(f"{Fore.RED}Error {url}{Fore.RESET}")
    except Exception as e:
        print(f"{Fore.RED}Error:  {url}{Fore.RESET}")

open(output_file, 'w').close()

class Proxy:
    def __init__(self, method, proxy):
        if method.lower() not in ["http", "https"]:
            raise NotImplementedError("Only HTTP and HTTPS are supported")
        self.method = method.lower()
        self.proxy = proxy

    def is_valid(self):
        return re.match(r"\d{1,3}(?:\.\d{1,3}){3}(?::\d{1,5})?$", self.proxy)

    def check(self, site, timeout, user_agent):
        url = self.method + "://" + self.proxy
        proxy_support = urllib.request.ProxyHandler({self.method: url})
        opener = urllib.request.build_opener(proxy_support)
        urllib.request.install_opener(opener)
        req = urllib.request.Request(self.method + "://" + site)
        req.add_header("User-Agent", user_agent)
        try:
            start_time = time()
            urllib.request.urlopen(req, timeout=timeout)
            end_time = time()
            time_taken = end_time - start_time
            return True, time_taken, None
        except Exception as e:
            return False, 0, e

    def __str__(self):
        return self.proxy

def verbose_print(verbose, message):
    if verbose:
        print(message)

def check(file, timeout, method, site, verbose, random_user_agent):
    proxies = []
    with open(file, "r") as f:
        for line in f:
            proxies.append(Proxy(method, line.replace("\n", "")))

    print(f"{Fore.GREEN}Checking {Fore.YELLOW}{len(proxies)} {Fore.GREEN}Proxy")
    proxies = filter(lambda x: x.is_valid(), proxies)
    valid_proxies = []
    user_agent = random.choice(user_agents)

    def check_proxy(proxy, user_agent):
        new_user_agent = user_agent
        if random_user_agent:
            new_user_agent = random.choice(user_agents)
        valid, time_taken, error = proxy.check(site, timeout, new_user_agent)
        message = {
            True: f"{proxy} is valid, took {time_taken} seconds",
            False: f"{proxy} is invalid: {repr(error)}",
        }[valid]
        verbose_print(verbose, message)
        valid_proxies.extend([proxy] if valid else [])

    threads = []
    for proxy in proxies:
        t = threading.Thread(target=check_proxy, args=(proxy, user_agent))
        threads.append(t)

    for t in threads:
        t.start()

    for t in threads:
        t.join()

    with open(file, "w") as f:
        for proxy in valid_proxies:
            f.write(str(proxy) + "\n")

    print(f"{Fore.GREEN}Found {Fore.YELLOW}{len(valid_proxies)} {Fore.GREEN}valid proxies")


def verbose_print(verbose, message):
    if verbose:
        print(message)

for url in proxy_urls:
    download_and_save_proxies(url, output_file)
    
with open('proxy.txt', 'r') as ceki:
    jumlh = sum(1 for line in ceki)
    
print(f"\n{Fore.WHITE}( {Fore.YELLOW}{jumlh} {Fore.WHITE}) {Fore.GREEN}Proxy Sudah Di Unduh, Mau Check? {Fore.WHITE}({Fore.GREEN}Y{Fore.WHITE}/{Fore.RED}N{Fore.WHITE}): ", end="")
choice = input().strip().lower()

if choice == 'y' or choice == 'Y':
    user_agents = [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3",
        "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:89.0) Gecko/20100101 Firefox/89.0",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.0 Safari/605.1.15",
    ]
    
    parser = argparse.ArgumentParser()
    parser.add_argument("-t", "--timeout", type=int, default=20, help="Dismiss the proxy after -t seconds")
    parser.add_argument("-p", "--proxy", default="http", help="Check HTTPS or HTTP proxies")
    parser.add_argument("-s", "--site", default="https://google.com/", help="Check with specific website like google.com")
    parser.add_argument("-v", "--verbose", action="store_true", help="Increase output verbosity")
    parser.add_argument("-r", "--random_agent", action="store_true", help="Use a random user agent per proxy")
    
    args = parser.parse_args()
    check(file=output_file, timeout=args.timeout, method=args.proxy, site=args.site, verbose=args.verbose, random_user_agent=args.random_agent)
    sys.exit(0)
else:
    print(f"{Fore.YELLOW}Terima Kasih, Telah Menggunakan Script Saya!.\n By Its (Lintar) \n")
